"use client"

import { useState } from "react"
import { VitalityGauge } from "@/components/vitality-gauge"
import type { EnergyLevel } from "@shared/schema"

export default function Page() {
  const [energyLevel, setEnergyLevel] = useState<EnergyLevel>("medium")
  const [streak, setStreak] = useState(14)

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <VitalityGauge energyLevel={energyLevel} streak={streak} onEnergyChange={setEnergyLevel} />
      </div>
    </main>
  )
}
