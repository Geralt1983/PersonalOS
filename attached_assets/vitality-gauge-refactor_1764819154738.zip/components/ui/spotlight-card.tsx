"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface SpotlightCardProps extends React.ComponentProps<"div"> {
  spotlightColor?: string
}

export function SpotlightCard({
  className,
  spotlightColor = "rgba(255, 255, 255, 0.1)",
  ...props
}: SpotlightCardProps) {
  const [mousePosition, setMousePosition] = React.useState({ x: 0, y: 0 })
  const divRef = React.useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!divRef.current) return

    const rect = divRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setMousePosition({ x, y })
  }

  const handleMouseLeave = () => {
    setMousePosition({ x: 0, y: 0 })
  }

  return (
    <div
      ref={divRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn(
        "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm relative overflow-hidden",
        className,
      )}
      {...props}
    >
      {/* Spotlight effect */}
      <div
        className="pointer-events-none absolute transition-opacity duration-300 opacity-0 hover:opacity-100"
        style={{
          background: `radial-gradient(circle 400px at ${mousePosition.x}px ${mousePosition.y}px, ${spotlightColor}, transparent 80%)`,
          left: 0,
          top: 0,
          right: 0,
          bottom: 0,
        }}
      />

      {/* Content wrapper to ensure content is above spotlight */}
      <div className="relative z-10">{props.children}</div>
    </div>
  )
}
